(() => {
  'use strict';
  const cfg = window.OLAVIVA_CONFIG || {};
  const $ = (id) => document.getElementById(id);
  const escapeHTML = (s) => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let catalogo = [];
  function panel(texto, error = false) {
    $('monitor-mensaje').textContent = texto;
    $('led').textContent = error ? '● INCIDENCIA DETECTADA' : '● SERVICIO OPERATIVO';
    document.body.classList.toggle('error', error);
  }
  function datosPanel(){
    $('monitor-responsable').textContent = cfg.responsable || 'Sin asignar';
    $('monitor-entorno').textContent = cfg.entorno || 'No definido';
    $('monitor-log').textContent = cfg.nivelLog || 'No definido';
    $('monitor-total').textContent = String(catalogo.length);
    $('hero-total').textContent = String(catalogo.length);
  }
  function crearSelect(id,propiedad) {
    const select = $(id);
    [...new Set(catalogo.map(item => item[propiedad]))].sort((a,b)=>a.localeCompare(b,'es')).forEach(valor => {
      const opt = document.createElement('option');opt.value=valor;opt.textContent=valor;select.appendChild(opt);
    });
  }
  function render(){
    const isla = $('filtro-isla').value;
    const tipo = $('filtro-tipo').value;
    const q = $('buscar').value.trim().toLocaleLowerCase('es');
    const visibles = catalogo.filter(x => (!isla||x.isla===isla) && (!tipo||x.tipo===tipo) && (!q||`${x.nombre} ${x.lugar} ${x.tipo}`.toLocaleLowerCase('es').includes(q)));
    $('contador').textContent = `${visibles.length} de ${catalogo.length}`;
    $('texto-resultados').textContent = `${visibles.length} experiencias disponibles con los filtros actuales`;
    $('tarjetas').innerHTML = visibles.length ? visibles.map(x=>`<article class="card"><img class="card-img" src="${escapeHTML(x.imagen)}" alt="Ilustración de ${escapeHTML(x.tipo)}"><div class="card-body"><div class="topline"><span class="tag">${escapeHTML(x.isla)}</span><span>${escapeHTML(x.duracion)} · ${escapeHTML(x.nivel)}</span></div><h3>${escapeHTML(x.nombre)}</h3><p>${escapeHTML(x.descripcion)}</p><div class="card-foot"><div class="price"><strong>${Number(x.precio)} €</strong> <small>/ persona</small></div><button class="book" type="button" data-plan="${escapeHTML(x.nombre)}" data-id="${escapeHTML(x.id)}">Me interesa ↗</button></div></div></article>`).join('') : '<p class="empty">No encontramos experiencias con esos filtros. Prueba otra búsqueda.</p>';
  }
  async function iniciar(){
    datosPanel();
    try {
      if(!cfg.urlExperiencias) throw new Error('No se ha configurado la URL del catálogo');
      const r = await fetch(cfg.urlExperiencias,{cache:'no-store'});
      if(!r.ok) throw new Error(`HTTP ${r.status}`);
      const data=await r.json();
      if(!Array.isArray(data)) throw new Error('Formato de datos incorrecto');
      catalogo=data;crearSelect('filtro-isla','isla');crearSelect('filtro-tipo','tipo');
      catalogo.forEach(x=>{const opt=document.createElement('option');opt.value=x.id;opt.textContent=x.nombre+' · '+x.isla;$('reserva-experiencia').appendChild(opt)});datosPanel();render();
      panel('SERVICIO PREPARADO · CATÁLOGO CARGADO · CONFIGURACIÓN APLICADA');
      if(cfg.nivelLog==='DEBUG') console.debug('OlaViva: catálogo recibido',catalogo.length);
    } catch(e){
      $('texto-resultados').textContent='No se ha podido cargar el catálogo';
      $('tarjetas').innerHTML='<div class="unloaded">ERROR: no se ha podido cargar el catálogo ('+escapeHTML(e.message)+'). Revisa la configuración y la ruta del JSON.</div>';
      panel('ERROR: CATÁLOGO NO DISPONIBLE',true);
      console.error('OlaViva: fallo de carga',e);
    }
  }
  ['filtro-isla','filtro-tipo','buscar'].forEach(id => $(id).addEventListener(id==='buscar'?'input':'change',render));
  $('limpiar').addEventListener('click',()=>{$('filtro-isla').value='';$('filtro-tipo').value='';$('buscar').value='';render()});
  $('tarjetas').addEventListener('click', e=>{const b=e.target.closest('button[data-plan]');if(!b)return;$('reserva-experiencia').value=b.dataset.id;$('resultado-reserva').textContent='Has elegido '+b.dataset.plan+'. Completa los datos para simular la solicitud.';$('reserva').scrollIntoView({behavior:'smooth',block:'center'})});
  $('form-reserva').addEventListener('submit',e=>{e.preventDefault();const x=catalogo.find(x=>x.id===$('reserva-experiencia').value);if(!x)return;const fecha=$('reserva-fecha').value;const personas=Number($('reserva-personas').value);$('resultado-reserva').textContent=`Solicitud de demostración: ${x.nombre} · ${fecha} · ${personas} participante(s). No se ha registrado ninguna reserva real.`;});
  iniciar();
})();
