// Parámetros del despliegue. Editar SOLO los valores indicados en la guía.
window.OLAVIVA_CONFIG = {
  entorno: 'piloto',
  nivelLog: 'DEBUG',
  responsable: 'Pendiente de asignar',
  urlExperiencias: './datos/catalogo-viejo.json',
  version: '1.0.0',
  moneda: 'EUR'
};
